
const initialQuestions = [
{id:1,level:"mudah",type:"question",format:"mcq",text:"Apa yang dimaksud dengan algoritma?",options:["Urutan langkah logis untuk menyelesaikan masalah","Perangkat untuk mengetik kode","Nama sistem operasi"],correct:0,answer:"Urutan langkah logis untuk menyelesaikan masalah",explain:"Algoritma adalah urutan langkah yang logis dan terstruktur untuk menyelesaikan suatu masalah."},
{id:2,level:"mudah",type:"question",format:"mcq",text:"Manakah contoh nama variabel yang mudah dipahami?",options:["x1","totalNilai","????"],correct:1,answer:"totalNilai",explain:"Nama variabel sebaiknya jelas, bermakna, dan mengikuti aturan penamaan bahasa pemrograman."},
{id:3,level:"mudah",type:"challenge",format:"mcq",text:"Tantangan cepat: tipe data yang cocok untuk menyimpan bilangan bulat adalah ...",options:["int","string","boolean"],correct:0,answer:"int",explain:"Dalam banyak bahasa pemrograman, int digunakan untuk menyimpan bilangan bulat."},
{id:4,level:"mudah",type:"question",format:"mcq",text:"Apa fungsi flowchart?",options:["Menggambarkan alur proses dengan simbol","Menghapus semua bug otomatis","Mempercepat internet"],correct:0,answer:"Menggambarkan alur proses dengan simbol",explain:"Flowchart menyajikan alur algoritma atau proses secara visual menggunakan simbol."},
{id:5,level:"mudah",type:"question",format:"mcq",text:"Operator untuk penjumlahan dalam banyak bahasa pemrograman adalah ...",options:["+","=","/="],correct:0,answer:"+",explain:"Operator + digunakan untuk operasi penjumlahan pada tipe data numerik."},
{id:6,level:"sedang",type:"question",format:"mcq",text:"Perhatikan: nilai = 4; nilai = nilai + 3. Berapa nilai akhir variabel nilai?",options:["3","4","7"],correct:2,answer:"7",explain:"Nilai awal 4 ditambah 3, sehingga nilai akhirnya 7."},
{id:7,level:"sedang",type:"challenge",format:"mcq",text:"Jika nilai = 45 dan syarat if (nilai >= 75), apakah kondisi bernilai benar?",options:["Benar","Salah","Tidak bisa ditentukan"],correct:1,answer:"Salah",explain:"45 tidak lebih besar atau sama dengan 75, jadi kondisi bernilai false."},
{id:8,level:"sedang",type:"question",format:"mcq",text:"Struktur if-else digunakan untuk ...",options:["Memilih tindakan berdasarkan kondisi","Mengulang tanpa batas saja","Menyimpan gambar"],correct:0,answer:"Memilih tindakan berdasarkan kondisi",explain:"Percabangan memilih blok perintah yang dijalankan berdasarkan hasil kondisi."},
{id:9,level:"sedang",type:"question",format:"mcq",text:"Kode for yang mencetak i dari 1 sampai 3 akan mencetak berapa angka?",options:["2 angka","3 angka","4 angka"],correct:1,answer:"3 angka",explain:"Jika batasnya inklusif dari 1 sampai 3, angka yang dicetak adalah 1, 2, dan 3."},
{id:10,level:"sulit",type:"question",format:"mcq",text:"Apa kemungkinan masalah pada while (x > 0) jika nilai x tidak pernah diubah di dalam loop?",options:["Loop dapat berjalan terus","Program pasti selesai","Variabel otomatis menjadi nol"],correct:0,answer:"Loop dapat berjalan terus",explain:"Jika kondisi selalu benar dan tidak ada perubahan yang membuatnya salah, loop dapat menjadi tak berujung."},
{id:11,level:"sulit",type:"challenge",format:"mcq",text:"Bug hunt: variabel i dimulai dari 1, kondisi i <= 5, tetapi i tidak pernah bertambah. Apa risikonya?",options:["Loop tidak berhenti","Loop berjalan tepat sekali","Tidak ada risiko"],correct:0,answer:"Loop tidak berhenti",explain:"Variabel kontrol perlu diperbarui agar kondisi perulangan akhirnya menjadi salah."},
{id:12,level:"sulit",type:"question",format:"mcq",text:"Pada perulangan bersarang, perulangan di dalam perulangan disebut ...",options:["Nested loop","Branching","Casting"],correct:0,answer:"Nested loop",explain:"Nested loop adalah perulangan yang berada di dalam perulangan lainnya."}
];
let questions = [...initialQuestions];
let editingId = null, mode = "solo", level = "mudah", players = [], current = 0, turn = 0, diceValue = 1, gameOver = false, lastRoll = false, questionCounter = 0, usedQuestionIds = new Set(), lastQuestion = null;
const PCOL=['#3157d5','#ff766e','#16a36a','#e69a14','#8664db'];
// Tangga pendek (naik 11-14 petak); kepala ular = petak tantangan
const ladders={3:17,8:19,22:35,29:41,47:60,53:67,72:86,77:91};
const snakes={26:11,38:21,49:32,63:45,74:57,88:70,95:76,99:80};
const eventCells={};
[[5,12,14,18,25,30,34,40,43,51,56,59,66,71,75,82,90,93],[7,15,23,33,42,52,64,73,84,92],[13,37,50,68,85]].forEach((a,i)=>a.forEach(n=>eventCells[n]=['question','bonus','duel'][i]));
const diceFaces=["⚀","⚁","⚂","⚃","⚄","⚅"];
let extraTurn=false,lastCorrect=false,DU=null;
const MATERI={
mudah:{t:'Dasar-dasar pemrograman',p:[['Algoritma','Urutan langkah logis untuk menyelesaikan masalah. Flowchart menggambarkannya dengan simbol.'],['Variabel','Wadah penyimpan nilai, misalnya totalNilai = 80. Beri nama yang jelas.'],['Tipe data','int untuk bilangan bulat, string untuk teks, boolean untuk benar/salah.'],['Operator','+ menjumlah, - mengurang, * mengali, / membagi, = memberi nilai.']]},
sedang:{t:'Alur program dan percabangan',p:[['Menelusuri kode','Ikuti baris demi baris: nilai = 4 lalu nilai = nilai + 3 menghasilkan 7.'],['Kondisi','Perbandingan menghasilkan benar atau salah, misalnya 45 >= 75 bernilai salah.'],['if-else','Blok if berjalan bila kondisi benar, selain itu blok else yang berjalan.'],['Perulangan for','Mengulang perintah dalam jumlah tertentu. i dari 1 sampai 3 berarti 3 kali.']]},
sulit:{t:'Perulangan dan debugging',p:[['Loop tak berujung','while terus berjalan jika kondisinya tidak pernah menjadi salah.'],['Variabel kontrol','Nilainya harus berubah (misalnya i = i + 1) agar loop berhenti.'],['Nested loop','Perulangan di dalam perulangan; jumlah putaran = luar × dalam.'],['Debugging','Cari bug dengan menelusuri nilai variabel pada setiap langkah.']]}};
function showScreen(id){document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));document.getElementById(id).classList.add('active');window.scrollTo({top:0,behavior:'smooth'});if(id==='admin')renderAdminQuestions();}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400);}
function renderNames(){const n=+document.getElementById('playerCount').value;let h='';for(let i=2;i<=n;i++)h+=`<div class="field"><label for="gname${i}">Nama pemain ${i}</label><input id="gname${i}" value="Pemain ${i}" maxlength="22"></div>`;document.getElementById('groupNames').innerHTML=h;}
function selectMode(m,el){mode=m;document.querySelectorAll('[data-mode]').forEach(x=>x.classList.remove('selected'));el.classList.add('selected');document.getElementById('player2Field').style.display=m==='group'?'block':'none';if(m==='group')renderNames();}
function selectLevel(l,el){level=l;document.querySelectorAll('[data-level]').forEach(x=>x.classList.remove('selected'));el.classList.add('selected');}
function goLevel(){if(!document.getElementById('player1').value.trim()){toast('Isi nama pemain terlebih dahulu.');return;}showScreen('level');}
function showMateri(){const m=MATERI[level];document.getElementById('materiBody').innerHTML=`<span class="pill">LEVEL ${level.toUpperCase()}</span><h2 style="margin:10px 0">${m.t}</h2><div class="tutorial-list">${m.p.map((x,i)=>`<div class="tutorial-item"><div class="num">${i+1}</div><div><b>${x[0]}</b><p>${x[1]}</p></div></div>`).join('')}</div>`;showScreen('materi');}
function startGame(){
  const names=[document.getElementById('player1').value.trim()||'Pemain 1'];
  if(mode==='solo')names.push('Bot Edu');else{const n=+document.getElementById('playerCount').value;for(let i=2;i<=n;i++)names.push(document.getElementById('gname'+i).value.trim()||'Pemain '+i);}
  players=names.map((name,i)=>({name,pos:1,score:0,correct:0,answered:0,bot:mode==='solo'&&i===1}));
  current=0;turn=0;diceValue=1;gameOver=false;lastRoll=false;extraTurn=false;questionCounter=0;usedQuestionIds=new Set();lastQuestion=null;
  document.getElementById('gameLevelPill').textContent='LEVEL '+level.toUpperCase();
  document.getElementById('diceFace').textContent='🎲';document.getElementById('rollHint').textContent='Tekan tombol untuk jalan.';document.getElementById('activity').textContent='Permainan dimulai. Semangat!';
  showScreen('game');renderBoard();renderStats();updateTurn();
}
function cellType(n){if(ladders[n])return 'ladder';if(snakes[n])return 'snake';return eventCells[n]||'';}
function iconFor(t){return ({question:'📝',bonus:'🎁',duel:'⚔️',ladder:'🪜',snake:'🐍',start:'🚩',finish:'🏁'})[t]||'';}
function renderBoard(){
  const board=document.getElementById('board');board.innerHTML='';
  for(let row=9;row>=0;row--){
    for(let col=0;col<10;col++){
      const n=row%2===0?row*10+col+1:row*10+(10-col),c=document.createElement('div');
      let t=cellType(n);if(n===1)t='start';if(n===100)t='finish';
      const lab=ladders[n]?'→'+ladders[n]:snakes[n]?'UJI →'+snakes[n]:({question:'SOAL',bonus:'BONUS',duel:'DUEL'})[t]||'';
      c.className='cell '+t;c.dataset.cell=n;
      c.innerHTML=`<span class="n">${n}</span>${t?`<span class="type">${iconFor(t)}</span>`:''}${lab?`<span class="event-label">${lab}</span>`:''}`;
      const here=players.map((p,i)=>({p,i})).filter(x=>x.p.pos===n);
      if(here.length){const w=document.createElement('div');w.className='tokens';here.forEach(x=>{const k=document.createElement('span');k.className='token';k.style.background=PCOL[x.i];k.textContent=x.p.bot?'B':x.i+1;w.appendChild(k);});c.appendChild(w);}
      board.appendChild(c);
    }
  }
}
function renderStats(){
  document.getElementById('scorePanel').innerHTML=players.map((p,i)=>`<div class="score-line"><span><span style="color:${PCOL[i]}">●</span> ${escapeHtml(p.name)}</span><b>${p.score} poin</b></div>`).join('');
  document.getElementById('progressPanel').innerHTML=players.map(p=>`<div style="margin:10px 0"><div class="row between" style="font-size:.82rem"><b>${escapeHtml(p.name)}</b><span>Petak ${p.pos}/100</span></div><div class="progressbar"><div style="width:${p.pos}%"></div></div></div>`).join('');
}
function updateTurn(){
  if(gameOver)return;
  const p=players[current];document.getElementById('turnLabel').textContent='Giliran: '+p.name;document.getElementById('activeName').textContent=p.name;
  const btn=document.getElementById('rollBtn');btn.disabled=p.bot||lastRoll;btn.textContent=lastRoll?'Selesaikan kartu dulu':(p.bot?'Giliran bot…':'Lempar dadu');
  if(p.bot&&!lastRoll)setTimeout(doRoll,750);
}
function rollDice(){if(!players[current].bot)doRoll();}
function doRoll(){
  if(gameOver||lastRoll)return;
  const p=players[current],old=p.pos;diceValue=Math.floor(Math.random()*6)+1;lastRoll=true;
  document.getElementById('diceFace').textContent=diceFaces[diceValue-1];document.getElementById('rollHint').textContent=p.name+' mendapat '+diceValue+'.';
  p.pos=Math.min(100,p.pos+diceValue);
  document.getElementById('activity').textContent=`${p.name} mendapat ${diceValue} dan bergerak dari ${old} ke ${p.pos}.`;
  renderBoard();renderStats();document.getElementById('rollBtn').disabled=true;document.getElementById('rollBtn').textContent='Memproses…';
  setTimeout(resolveLanding,500);
}
function resolveLanding(){
  const p=players[current],pos=p.pos;
  if(pos>=100)return finishGame(current);
  if(ladders[pos]){showModal('🪜 Tangga!',`Mendarat di petak ${pos}. Naik tangga ke petak ${ladders[pos]}!`,'good',()=>{p.pos=ladders[pos];afterAction();});return;}
  if(snakes[pos]){askQuestion('challenge');return;}
  const t=eventCells[pos];
  if(t==='question')askQuestion('question');else if(t==='bonus')bonusSpin();else if(t==='duel')duelEvent();else afterAction();
}
function getQuestion(type){
  const qt=type==='challenge'?'challenge':'question';
  let pool=questions.filter(q=>q.level===level&&q.type===qt);
  if(!pool.length)pool=questions.filter(q=>q.level===level);
  if(!pool.length)pool=questions;
  if(!pool.length)return null;
  let av=pool.filter(q=>!usedQuestionIds.has(q.id));
  if(!av.length){pool.forEach(q=>usedQuestionIds.delete(q.id));av=pool;}
  const q=av[Math.floor(Math.random()*av.length)];usedQuestionIds.add(q.id);return q;
}
function askQuestion(type){
  const q=getQuestion(type);if(!q){showModal('Bank soal kosong','Tambahkan soal melalui Panel Guru terlebih dahulu.','neutral',()=>afterAction());return;}
  lastQuestion=q;questionCounter++;
  const p=players[current],ch=type==='challenge';
  const opts=q.format==='mcq'?`<div class="answer-list">${q.options.map((op,i)=>`<button class="answer-option" onclick="selectAnswer(${i})"><b>${String.fromCharCode(65+i)}.</b> ${escapeHtml(op)}</button>`).join('')}</div>`:`<div class="field"><label>Jawabanmu</label><input id="shortResponse" placeholder="Ketik jawaban singkat..." autocomplete="off"></div>`;
  showCustomModal(`<span class="pill">${ch?'🐍⚡ TANTANGAN · benar +15 & selamat · salah turun ular':'📝 KARTU SOAL · +10'}</span><h2 id="modalTitle">${ch?'Kepala ular! Jawab untuk selamat':'Saatnya menjawab!'}</h2><div class="muted">Pemain: ${escapeHtml(p.name)} · Level ${level}</div><div class="question-text">${escapeHtml(q.text)}</div>${opts}<div id="answerFeedback"></div><div class="modal-actions"><button class="btn btn-primary" id="submitAnswer" onclick="submitAnswer('${q.format}','${type}')">Periksa jawaban</button><button class="btn btn-ghost hidden" id="continueAnswer" onclick="continueAfter('${type}')">Lanjutkan</button></div>`);
  window.selectedAnswer=null;
  if(p.bot)setTimeout(()=>{if(q.format==='mcq')selectAnswer(Math.random()<.65?q.correct:(q.correct+1)%q.options.length);else document.getElementById('shortResponse').value=Math.random()<.6?q.answer:'-';submitAnswer(q.format,type);setTimeout(()=>continueAfter(type),2600);},1400);
}
function selectAnswer(i){window.selectedAnswer=i;document.querySelectorAll('.answer-option').forEach((b,j)=>b.classList.toggle('selected',i===j));}
function submitAnswer(format,type){
  const q=lastQuestion,p=players[current];let correct=false;
  if(format==='mcq'){if(window.selectedAnswer==null){toast('Pilih salah satu jawaban dulu.');return;}correct=window.selectedAnswer===q.correct;}
  else{const norm=s=>String(s).trim().toLowerCase().replace(/\s+/g,' ');const v=norm(document.getElementById('shortResponse')?.value||'');if(!v){toast('Tulis jawaban dulu.');return;}correct=v===norm(q.answer);}
  p.answered++;lastCorrect=correct;if(correct){p.correct++;p.score+=type==='challenge'?15:10;}
  const info=type==='challenge'?(correct?'+15 poin. Kamu selamat dari ular!':`Pion turun lewat ular ke petak ${snakes[p.pos]}.`):(correct?'+10 poin.':'Tidak ada pengurangan poin.');
  const f=document.getElementById('answerFeedback');f.className='feedback '+(correct?'good':'bad');
  f.innerHTML=`<b>${correct?'✅ Benar!':'❌ Belum tepat.'}</b> ${info}<br><b>Pembahasan materi:</b> ${escapeHtml(q.explain||('Jawaban yang diharapkan: '+q.answer))}`;
  document.querySelectorAll('.answer-option').forEach((b,i)=>{b.disabled=true;if(i===q.correct)b.classList.add('correct');else if(i===window.selectedAnswer&&!correct)b.classList.add('wrong');});
  document.getElementById('submitAnswer').classList.add('hidden');document.getElementById('continueAnswer').classList.remove('hidden');
  document.getElementById('activity').textContent=`${p.name} ${correct?'menjawab benar':'perlu mempelajari kembali'} kartu ${type==='challenge'?'tantangan':'soal'}.`;
  renderStats();
}
function continueAfter(type){
  if(!document.getElementById('modalBackdrop').classList.contains('show'))return;
  closeModal();const p=players[current];
  if(type==='challenge'&&!lastCorrect&&snakes[p.pos])p.pos=snakes[p.pos];
  afterAction();
}
function bonusSpin(){
  const p=players[current];
  const outs=[{n:'Maju 3 langkah',x:'Pion maju 3 petak.',a:()=>{p.pos=Math.min(99,p.pos+3);}},{n:'Maju 2 langkah',x:'Pion maju 2 petak.',a:()=>{p.pos=Math.min(99,p.pos+2);}},{n:'Bonus +10 poin',x:'Kamu mendapat +10 poin.',a:()=>{p.score+=10;}},{n:'Bonus +5 poin',x:'Kamu mendapat +5 poin.',a:()=>{p.score+=5;}},{n:'Giliran ekstra',x:'Kamu boleh melempar dadu lagi.',a:()=>{extraTurn=true;}}];
  const o=outs[Math.floor(Math.random()*outs.length)];
  showCustomModal(`<h2>🎡 Roda bonus</h2><div class="feedback neutral" id="spinBox" style="text-align:center;font-size:1.25rem;font-weight:800">Memutar…</div><div class="modal-actions"><button class="btn btn-primary hidden" id="spinOk">Lanjutkan</button></div>`);
  let k=0;const iv=setInterval(()=>{document.getElementById('spinBox').textContent='🎡 '+outs[k++%outs.length].n;},110);
  setTimeout(()=>{
    clearInterval(iv);const b=document.getElementById('spinBox');b.className='feedback good';b.style.fontSize='1.25rem';
    b.innerHTML=`🎁 ${o.n}<div style="font-size:.95rem;font-weight:500;margin-top:6px">${o.x}</div>`;
    const ok=document.getElementById('spinOk');ok.classList.remove('hidden');
    ok.onclick=()=>{closeModal();o.a();document.getElementById('activity').textContent=`${p.name}: ${o.n}.`;afterAction();};
    if(p.bot)setTimeout(()=>ok.click(),1600);
  },1700);
}
function duelEvent(){
  const ai=current;let bi;
  if(mode==='solo')bi=1-ai;else{const o=players.map((_,i)=>i).filter(i=>i!==ai);bi=o[Math.floor(Math.random()*o.length)];}
  const D=[players[ai],players[bi]],q=getQuestion('question');
  if(!q){afterAction();return;}
  DU={q,D,done:false,locked:[false,false],t:10,iv:null};
  const col=i=>`<div><b>${escapeHtml(D[i].name)}</b><div class="answer-list">${q.options.map((op,j)=>`<button class="answer-option" data-d="${i}" onclick="duelTap(${i},${j})" ${D[i].bot?'disabled':''}>${String.fromCharCode(65+j)}. ${escapeHtml(op)}</button>`).join('')}</div></div>`;
  showCustomModal(`<span class="pill">⚔️ DUEL KILAT · tercepat menjawab benar +10</span><h2>${escapeHtml(D[0].name)} vs ${escapeHtml(D[1].name)}</h2><div class="muted" id="duelTimer">⏱ 10 detik</div><div class="question-text">${escapeHtml(q.text)}</div><div class="duel-grid">${col(0)}${col(1)}</div><div id="answerFeedback"></div><div class="modal-actions" id="duelActions"></div>`);
  DU.iv=setInterval(()=>{DU.t--;const e=document.getElementById('duelTimer');if(e)e.textContent='⏱ '+DU.t+' detik';if(DU.t<=0)endDuel(-1);},1000);
  D.forEach((p,i)=>{if(p.bot)setTimeout(()=>duelTap(i,Math.random()<.6?q.correct:(q.correct+1)%q.options.length),1500+Math.random()*5500);});
}
function duelTap(i,j){
  if(!DU||DU.done||DU.locked[i])return;
  if(j===DU.q.correct){endDuel(i);return;}
  DU.locked[i]=true;document.querySelectorAll(`[data-d="${i}"]`).forEach(b=>b.disabled=true);
  if(DU.locked[0]&&DU.locked[1])endDuel(-1);
}
function endDuel(w){
  if(!DU||DU.done)return;DU.done=true;clearInterval(DU.iv);
  const {q,D}=DU,win=w>=0?D[w]:null;
  D.forEach(p=>p.answered++);if(win){win.score+=10;win.correct++;}
  document.querySelectorAll('.duel-grid .answer-option').forEach(b=>{b.disabled=true;const idx=[...b.parentNode.children].indexOf(b);if(idx===q.correct)b.classList.add('correct');});
  const f=document.getElementById('answerFeedback');f.className='feedback '+(win?'good':'neutral');
  f.innerHTML=`<b>${win?escapeHtml(win.name)+' paling cepat menjawab benar! +10 poin':'Tidak ada yang menjawab benar tepat waktu. Tidak ada poin.'}</b><br>Jawaban: ${escapeHtml(q.answer)}.<br><b>Pembahasan materi:</b> ${escapeHtml(q.explain||'')}`;
  document.getElementById('activity').textContent=win?`${win.name} menang duel.`:'Duel berakhir tanpa pemenang.';
  document.getElementById('duelActions').innerHTML='<button class="btn btn-primary" id="duelOk">Lanjutkan</button>';
  const ok=document.getElementById('duelOk');ok.onclick=()=>{closeModal();renderStats();afterAction();};
  if(players[current].bot)setTimeout(()=>ok.click(),2600);
}
function showModal(title,text,kind,onContinue){showCustomModal(`<h2 id="modalTitle">${title}</h2><div class="feedback ${kind||'neutral'}">${text}</div><div class="modal-actions"><button class="btn btn-primary" id="modalContinue">Lanjutkan</button></div>`);const b=document.getElementById('modalContinue');b.onclick=()=>{closeModal();if(onContinue)onContinue();};if(players[current]&&players[current].bot&&!gameOver)setTimeout(()=>b.click(),1800);}
function showCustomModal(html){document.getElementById('modalContent').innerHTML=html;document.getElementById('modalBackdrop').classList.add('show');}
function closeModal(){document.getElementById('modalBackdrop').classList.remove('show');}
function afterAction(){
  renderBoard();renderStats();lastRoll=false;
  if(players[current].pos>=100){finishGame(current);return;}
  if(extraTurn){extraTurn=false;toast(players[current].name+' mendapat giliran ekstra!');}else{current=(current+1)%players.length;turn++;}
  updateTurn();
}
function finishGame(winnerIndex){
  gameOver=true;const winner=players[winnerIndex];showScreen('result');
  document.getElementById('winnerTitle').textContent=winner.name+' mencapai finish!';
  document.getElementById('resultText').textContent='Permainan selesai. Gunakan ringkasan ini untuk merefleksikan proses belajar.';
  document.getElementById('resultStats').innerHTML=players.map(p=>`<div class="stat"><b>${p.score}</b><span>poin · ${escapeHtml(p.name)}</span><div class="muted" style="font-size:.78rem;margin-top:5px">${p.correct}/${p.answered} jawaban benar</div><div class="muted" style="font-size:.78rem">Petak ${p.pos}</div></div>`).join('');
}
function confirmExit(){showModal('Keluar dari permainan?','Progres sesi ini akan direset jika kamu memulai permainan baru.','neutral',()=>showScreen('home'));}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toggleQuestionFormat(){const short=document.getElementById('qFormat').value==='short';document.getElementById('mcqFields').classList.toggle('hidden',short);document.getElementById('shortFields').classList.toggle('hidden',!short);}
function resetQuestionForm(){editingId=null;['qText','optA','optB','optC','shortAnswer','qExplain'].forEach(id=>document.getElementById(id).value='');document.getElementById('qLevel').value='mudah';document.getElementById('qType').value='question';document.getElementById('qFormat').value='mcq';document.getElementById('qCorrect').value='0';toggleQuestionFormat();document.getElementById('formTitle').textContent='Tambah soal';}
function saveQuestion(){
  const text=document.getElementById('qText').value.trim(),format=document.getElementById('qFormat').value;
  if(!text){toast('Pertanyaan belum diisi.');return;}
  let options=[],correct=0,answer='';
  if(format==='mcq'){options=['optA','optB','optC'].map(id=>document.getElementById(id).value.trim());if(options.some(x=>!x)){toast('Isi semua pilihan A, B, dan C.');return;}correct=Number(document.getElementById('qCorrect').value);answer=options[correct];}
  else{answer=document.getElementById('shortAnswer').value.trim();if(!answer){toast('Isi jawaban singkat yang benar.');return;}}
  const item={id:editingId||Date.now(),level:document.getElementById('qLevel').value,type:document.getElementById('qType').value,format,text,options,correct,answer,explain:document.getElementById('qExplain').value.trim()||'Pelajari kembali konsep yang berkaitan dengan soal ini.'};
  if(editingId){questions=questions.map(q=>q.id===editingId?item:q);}else questions.push(item);
  resetQuestionForm();renderAdminQuestions();toast('Soal berhasil disimpan pada sesi browser ini.');
}
function editQuestion(id){
  const q=questions.find(x=>x.id===id);if(!q)return;editingId=id;
  document.getElementById('formTitle').textContent='Edit soal';
  document.getElementById('qText').value=q.text;document.getElementById('qLevel').value=q.level;document.getElementById('qType').value=q.type;document.getElementById('qFormat').value=q.format;
  document.getElementById('optA').value=q.options?.[0]||'';document.getElementById('optB').value=q.options?.[1]||'';document.getElementById('optC').value=q.options?.[2]||'';document.getElementById('qCorrect').value=String(q.correct||0);document.getElementById('shortAnswer').value=q.format==='short'?q.answer:'';document.getElementById('qExplain').value=q.explain||'';toggleQuestionFormat();window.scrollTo({top:0,behavior:'smooth'});
}
function deleteQuestion(id){if(!confirm('Hapus soal ini?'))return;questions=questions.filter(q=>q.id!==id);renderAdminQuestions();toast('Soal dihapus.');}
function renderAdminQuestions(){
  const filter=document.getElementById('filterLevel')?.value||'all',list=questions.filter(q=>filter==='all'||q.level===filter);
  document.getElementById('questionCount').textContent=questions.length;
  document.getElementById('questionRows').innerHTML=list.map(q=>`<tr><td><b>${escapeHtml(q.text)}</b><div class="muted">${q.format==='mcq'?'Pilihan ganda':'Isian singkat'} · ${q.type==='challenge'?'Tantangan':'Soal biasa'}</div></td><td>${q.level}</td><td>${escapeHtml(q.answer)}</td><td><div class="row"><button class="btn btn-ghost btn-small" onclick="editQuestion(${q.id})">Edit</button><button class="btn btn-danger btn-small" onclick="deleteQuestion(${q.id})">Hapus</button></div></td></tr>`).join('')||'<tr><td colspan="4" class="muted">Tidak ada soal pada filter ini.</td></tr>';
}
function exportQuestions(){const blob=new Blob([JSON.stringify(questions,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='bank-soal-eduladder.json';a.click();URL.revokeObjectURL(url);}
function importQuestions(event){const file=event.target.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const data=JSON.parse(reader.result);if(!Array.isArray(data))throw new Error();questions=data.map((q,i)=>({...q,id:q.id||Date.now()+i}));renderAdminQuestions();toast('Bank soal berhasil diimpor.');}catch(e){toast('File JSON tidak valid.');}};reader.readAsText(file);event.target.value='';}
function initMiniBoard(){const el=document.getElementById('miniBoard');for(let i=1;i<=25;i++){const d=document.createElement('div');d.className='mini-cell';d.textContent=i;el.appendChild(d);}}
initMiniBoard();renderAdminQuestions();renderNames();
